﻿using MVCApplication.Core.Contracts;
using Ninject.Extensions.Interception;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVCApplication.Infrastructure.Interceptors
{
    public class LoggingInterceptor //: IInterceptor
    {
    }
}
